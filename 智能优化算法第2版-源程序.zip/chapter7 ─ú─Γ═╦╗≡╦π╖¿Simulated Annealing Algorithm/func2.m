%%%%%%%%%%%%%%%%%%%%%%%%%%%��Ӧ�Ⱥ���%%%%%%%%%%%%%%%%%%%%%%%%%
function value=func2(x,y)
value=5*cos(x*y)+x*y+y*y*y;

